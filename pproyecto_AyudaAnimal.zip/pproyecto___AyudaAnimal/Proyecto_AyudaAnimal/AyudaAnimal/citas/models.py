from django.db import models
from datetime import date
from django.db import models
from django.core.exceptions import ValidationError
from django.db.models.fields.related import ForeignKey
from usuarios.models import Medico
from pacientes.models import Mascota

class HorarioVeterinario(models.Model):
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    fecha = models.DateField()
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()
    ocupado = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.medico.nombre} - {self.fecha} de {self.hora_inicio} a {self.hora_fin}"
    
    
def validar_dia(value):
    today = date.today()
    weekday = date.fromisoformat(f'{value}').weekday()

    if value < today:
        raise ValidationError('No puede elegir una fecha tardía a la fecha actual.')
    if (weekday == 5) or (weekday == 6):
        raise ValidationError('Elige un día laborable de la semana.')

class Cita_con_medico(models.Model):
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE, related_name='citas_medico')
    paciente = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='citas_paciente')
    dia = models.DateField(help_text="Introduzca una fecha para la cita", validators=[validar_dia])
    horario = models.ForeignKey(HorarioVeterinario, on_delete=models.CASCADE, related_name='citas')

    class Meta:
        unique_together = ('horario', 'dia')
    
    def __str__(self):
        return f"{self.paciente} con {self.medico} el {self.dia} a las {self.horario.hora_inicio} - {self.horario.hora_fin}"

    def clean(self):
        # Validar que la fecha de la cita coincida con la fecha del horario
        if self.dia != self.horario.fecha:
            raise ValidationError('La fecha de la cita y el horario deben coincidir.')

        # Puedes agregar aquí otras validaciones si lo necesitas

    






