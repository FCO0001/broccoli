from django import forms
from .models import Cita_con_medico, HorarioVeterinario

class formulario_cita_medico(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(formulario_cita_medico, self).__init__(*args, **kwargs)
        # Inicializa el campo 'horario' con horarios disponibles, si es necesario
        self.fields['horario'].queryset = HorarioVeterinario.objects.filter(ocupado=False)

    class Meta:
        model = Cita_con_medico
        fields = ['paciente', 'medico', 'dia', 'horario']
        widgets = {
            'dia': forms.DateInput(attrs={'type': 'date'}),
            'horario': forms.Select()
        }
