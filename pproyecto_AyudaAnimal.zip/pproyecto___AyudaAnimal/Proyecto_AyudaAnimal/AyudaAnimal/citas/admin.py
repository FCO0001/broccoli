from django.contrib import admin
from django.contrib import admin
from .models import Cita_con_medico

admin.site.register(Cita_con_medico)
# Register your models here.
