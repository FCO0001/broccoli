from django.urls import path
from . import views

urlpatterns = [
    path('agregar/agregar', views.showView, name='pacientes'),
    path('editar/editar', views.showViewEdit, name='editar'),
    path('editar/agregar', views.showView, name='pacientes')
]

