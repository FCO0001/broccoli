from django.contrib import admin
from .models import Mascota

admin.site.register(Mascota)
# Register your models here.
