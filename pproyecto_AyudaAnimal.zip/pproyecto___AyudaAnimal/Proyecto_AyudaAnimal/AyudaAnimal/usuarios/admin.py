from django.contrib import admin
from .models import Medico

admin.site.register(Medico)

# Register your models here.
